﻿#include "CountdownTimer.h"

ShootingGame::CountdownTimer::CountdownTimer()
{
}

ShootingGame::CountdownTimer::~CountdownTimer()
{
}

void ShootingGame::CountdownTimer::Tick(float deltaTime)
{
}
